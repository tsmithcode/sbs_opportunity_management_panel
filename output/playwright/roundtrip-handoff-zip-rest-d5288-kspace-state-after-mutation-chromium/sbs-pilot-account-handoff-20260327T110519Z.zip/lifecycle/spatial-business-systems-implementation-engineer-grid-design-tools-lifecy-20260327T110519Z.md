# Spatial Business Systems - Implementation Engineer, Grid Design Tools

- Opportunity ID: `opp_mn8sortc_u41so2`
- Stage: Positioning
- Status: active
- Source: Hiring manager referral
- Employment type: Full-time
- Location type: Remote
- Updated at: 2026-03-27T11:05:18.289Z

## Artifact Summary
- resume: Spatial Business Systems resume package (user_reviewed, complete)
- job_description: Spatial Business Systems opportunity description (user_reviewed, complete)
