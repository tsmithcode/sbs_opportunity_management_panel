# SBS intake follow-up draft

- Correspondence ID: `cor_mn8sortc_jd9s79`
- Opportunity ID: `opp_mn8sortc_5fnlxt`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T11:05:18.288Z

## Body
Thank you for the outreach. I have strong Autodesk platform experience and would like to continue the conversation about the design tools role.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
