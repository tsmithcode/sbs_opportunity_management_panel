# SBS positioning review draft

- Correspondence ID: `cor_mn8sortc_xj1dwk`
- Opportunity ID: `opp_mn8sortc_u41so2`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T11:05:18.288Z

## Body
I can contribute quickly in Autodesk-centric engineering workflows while staying hands-on and execution-focused.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
