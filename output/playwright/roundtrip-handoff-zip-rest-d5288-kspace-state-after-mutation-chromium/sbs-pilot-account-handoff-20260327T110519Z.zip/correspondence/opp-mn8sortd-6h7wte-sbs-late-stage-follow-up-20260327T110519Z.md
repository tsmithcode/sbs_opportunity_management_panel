# SBS late-stage follow-up

- Correspondence ID: `cor_mn8sortd_sbhvxx`
- Opportunity ID: `opp_mn8sortd_6h7wte`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T11:05:18.289Z

## Body
I appreciate the continued conversation. I would like to make sure scope, level, and compensation reflect both immediate contribution and long-term fit.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
