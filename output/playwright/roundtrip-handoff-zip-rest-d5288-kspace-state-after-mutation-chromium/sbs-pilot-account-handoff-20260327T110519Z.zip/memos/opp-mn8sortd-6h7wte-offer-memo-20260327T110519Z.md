# offer memo

- Memo ID: `memo_mn8sortd_5r7vgk`
- Opportunity ID: `opp_mn8sortd_6h7wte`
- Status: review
- Confidence: medium
- Human approved: No
- Created at: 2026-03-27T11:05:18.289Z

## Summary
Offer-review sample should demonstrate high-stakes guidance, compensation calibration, and explicit human review.
