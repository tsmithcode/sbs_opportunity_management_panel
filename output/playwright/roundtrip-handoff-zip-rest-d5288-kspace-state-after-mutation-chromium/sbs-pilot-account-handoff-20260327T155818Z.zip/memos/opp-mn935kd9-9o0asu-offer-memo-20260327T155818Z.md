# offer memo

- Memo ID: `memo_mn935kd9_s2mqc6`
- Opportunity ID: `opp_mn935kd9_9o0asu`
- Status: review
- Confidence: medium
- Human approved: No
- Created at: 2026-03-27T15:58:17.949Z

## Summary
Offer-review sample should demonstrate high-stakes guidance, compensation calibration, and explicit human review.
