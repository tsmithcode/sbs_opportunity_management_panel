# Habasit America - Application Engineer, Conveyor Solutions

- Opportunity ID: `opp_mn935kda_rgftpf`
- Stage: Closed won
- Status: closed_won
- Source: Mock sample based on Habasit America Suwanee operations
- Employment type: Full-time
- Location type: Hybrid - Suwanee, GA
- Updated at: 2026-03-26T20:10:00.000Z

## Artifact Summary
- resume: Habasit America resume package (user_reviewed, complete)
- job_description: Habasit America opportunity description (user_reviewed, complete)
- note: Application Engineer, Conveyor Solutions field intelligence (approved, complete)
