# Habasit America - Customer Operations And Continuous Improvement Lead

- Opportunity ID: `opp_mn935kdb_bdq6u8`
- Stage: Closed lost
- Status: closed_lost
- Source: Mock sample based on Habasit America Suwanee customer support and operations coordination
- Employment type: Full-time
- Location type: Hybrid - Suwanee, GA
- Updated at: 2026-03-27T20:10:00.000Z

## Artifact Summary
- resume: Habasit America resume package (user_reviewed, complete)
- job_description: Habasit America opportunity description (user_reviewed, complete)
- note: Customer Operations And Continuous Improvement Lead field intelligence (approved, complete)
