# Spatial Business Systems - Senior Design Tools Engineer

- Opportunity ID: `opp_mn935kd9_9o0asu`
- Stage: Debrief captured
- Status: active
- Source: Panel continuation
- Employment type: Full-time
- Location type: Remote
- Updated at: 2026-03-27T15:58:17.949Z

## Artifact Summary
- resume: Spatial Business Systems resume package (user_reviewed, complete)
- job_description: Spatial Business Systems opportunity description (user_reviewed, complete)
