# Habasit America fabrication shift discussion

- Correspondence ID: `cor_mn935kda_ea0cvj`
- Opportunity ID: `opp_mn935kda_6bom3f`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-07T16:40:00.000Z

## Body
I appreciate the chance to discuss the fabrication role in Suwanee. I can contribute on shift, stay coachable, and bring consistent attendance plus careful production follow-through.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
