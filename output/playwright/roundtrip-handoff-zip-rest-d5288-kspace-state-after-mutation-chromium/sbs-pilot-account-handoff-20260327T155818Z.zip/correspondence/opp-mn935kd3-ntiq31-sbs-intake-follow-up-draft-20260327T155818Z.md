# SBS intake follow-up draft

- Correspondence ID: `cor_mn935kd3_aipa1q`
- Opportunity ID: `opp_mn935kd3_ntiq31`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T15:58:17.943Z

## Body
Thank you for the outreach. I have strong Autodesk platform experience and would like to continue the conversation about the design tools role.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
