# SBS late-stage follow-up

- Correspondence ID: `cor_mn935kd9_fsx1q7`
- Opportunity ID: `opp_mn935kd9_9o0asu`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T15:58:17.949Z

## Body
I appreciate the continued conversation. I would like to make sure scope, level, and compensation reflect both immediate contribution and long-term fit.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
