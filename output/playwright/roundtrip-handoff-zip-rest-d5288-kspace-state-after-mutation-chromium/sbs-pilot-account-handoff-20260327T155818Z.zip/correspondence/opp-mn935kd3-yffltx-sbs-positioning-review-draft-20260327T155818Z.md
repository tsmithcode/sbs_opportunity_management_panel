# SBS positioning review draft

- Correspondence ID: `cor_mn935kd9_c90y4b`
- Opportunity ID: `opp_mn935kd3_yffltx`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T15:58:17.949Z

## Body
I can contribute quickly in Autodesk-centric engineering workflows while staying hands-on and execution-focused.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
