# Application Engineer, Conveyor Solutions scheduling follow-up

- Correspondence ID: `cor_mn935kda_v1vac0`
- Opportunity ID: `opp_mn935kda_rgftpf`
- Channel: email
- Status: sent
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-16T15:40:00.000Z

## Body
Thank you for the Suwanee conversation. I can support conveyor applications, technical customer translation, and plant-facing troubleshooting while staying grounded in fast operational follow-through.

Site reference: Habasit America, Suwanee, GA. Candidate is coordinating next-step timing and onsite expectations.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: Suwanee, GA onsite timing and follow-up scheduling.
