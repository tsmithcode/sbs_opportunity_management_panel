# Buyer-Facing Readiness Packet

Generated: `2026-03-27T15:58:22.774Z`

## Current Workspace
- Account: SBS Pilot Account
- Account type: enterprise
- Opportunity: Spatial Business Systems - Software Engineer, Design Tools
- Stage: Intake complete
- Buyer readiness stage: buyer_reviewable
- Deployment posture: Local-only browser workspace with ZIP handoff packages.

## Product Posture
- Local-only data custody in the current version
- Human-in-the-loop operating model
- Export-first recovery posture with ZIP handoff packages
- Candidate story, coaching, and buyer packet workflows are available in-product

## Release Confidence
- Last validated phase: Habasit town hall proof and seeded product hardening
- Local checks: 7
- CI checks: 2
- Last export: No export yet recorded

## Current Limits
- Desktop scenario proof and Habasit web/mobile town-hall proof are Chromium-only.
- The heavier generic mobile three-scenario proof exists as a separate extended script and is not part of the default release gate yet.
- Round-trip export/import verification remains Chromium-only.
- CI result status is surfaced through repo docs and workflow files, not a hosted dashboard.

## Expert Owners
- `Desktop Experience Director`
- `Mobile Experience Lead`
- `Town Hall Review Lead`
- `E2E Proof Lead`
- `Data Pipeline Validation Lead`
- `Visual QA Lead`
- `Responsive QA Lead`
- `CI / Release Automation Lead`
- `Browser Compatibility Lead`
- `QA / Reliability Lead`
- `Engineering Lead`
- `Release Manager`
