# Release Summary

## Summary
Release verification is scripted, automated, and visible. Local verification and CI both run the same build and browser gates, with desktop scenario proof plus a CEO-visible Habasit web/mobile town-hall proof on Chromium.

## Local Checks
- `npm run build`
- `npm run smoke`
- `npm run desktop:e2e`
- `npm run townhall:habasit`
- `npm run roundtrip`
- `npm run verify`
- `npm run smoke:cross-browser`

## CI Checks
- GitHub Actions verify workflow runs npm run verify on push, pull request, and manual dispatch.
- GitHub Actions cross-browser smoke matrix runs chromium, firefox, and webkit.

## Current Coverage
- Production build verification
- Chromium smoke verification for guided, admin, and About surfaces
- Chromium desktop end-to-end proof for three realistic opportunity scenarios
- Chromium Habasit America town-hall proof with one desktop web pass and one mobile pass against a 30-day seeded sample workspace
- Chromium round-trip verification for handoff ZIP and buyer packet ZIP
- Cross-browser smoke verification for chromium, firefox, and webkit

## Current Limits
- Desktop scenario proof and Habasit web/mobile town-hall proof are Chromium-only.
- The heavier generic mobile three-scenario proof exists as a separate extended script and is not part of the default release gate yet.
- Round-trip export/import verification remains Chromium-only.
- CI result status is surfaced through repo docs and workflow files, not a hosted dashboard.

## Expert Owners
- `Desktop Experience Director`
- `Mobile Experience Lead`
- `Town Hall Review Lead`
- `E2E Proof Lead`
- `Data Pipeline Validation Lead`
- `Visual QA Lead`
- `Responsive QA Lead`
- `CI / Release Automation Lead`
- `Browser Compatibility Lead`
- `QA / Reliability Lead`
- `Engineering Lead`
- `Release Manager`
