# Sensitive Support Profile

- Opportunity ID: `opp_mn935np6_g0hrd5`
- Enabled: Yes
- Included in export: Yes
- Updated at: 2026-03-26T16:25:00.000Z

## Categories
- layoff
- fired

## Notes
Candidate is processing a layoff and wants help keeping confidence and structure while re-entering a premium industrial environment.

## Encouragement Plan
Normalize the layoff, focus on measurable process wins, and use compensation education to rebuild decision confidence before the next offer cycle.
