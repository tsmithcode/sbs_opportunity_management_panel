# Spatial Business Systems - Senior Design Tools Engineer

- Opportunity ID: `opp_mn935np5_m0x5w9`
- Stage: Debrief captured
- Status: active
- Source: Panel continuation
- Employment type: Full-time
- Location type: Remote
- Updated at: 2026-03-27T15:58:22.265Z

## Artifact Summary
- resume: Spatial Business Systems resume package (user_reviewed, complete)
- job_description: Spatial Business Systems opportunity description (user_reviewed, complete)
