# Habasit America - Fabrication Technician, Timing Belt Operations

- Opportunity ID: `opp_mn935np6_wsphnk`
- Stage: Offer review
- Status: active
- Source: Mock sample based on Habasit America Suwanee fabrication operations
- Employment type: Full-time
- Location type: Onsite - Suwanee, GA
- Updated at: 2026-03-25T20:10:00.000Z

## Artifact Summary
- resume: Habasit America resume package (user_reviewed, complete)
- job_description: Habasit America opportunity description (user_reviewed, complete)
- note: Fabrication Technician, Timing Belt Operations field intelligence (approved, complete)
