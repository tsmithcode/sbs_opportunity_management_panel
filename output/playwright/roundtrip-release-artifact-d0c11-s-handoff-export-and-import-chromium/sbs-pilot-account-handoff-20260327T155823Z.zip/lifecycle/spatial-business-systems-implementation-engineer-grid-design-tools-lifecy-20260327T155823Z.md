# Spatial Business Systems - Implementation Engineer, Grid Design Tools

- Opportunity ID: `opp_mn935np3_12rm0o`
- Stage: Positioning
- Status: active
- Source: Hiring manager referral
- Employment type: Full-time
- Location type: Remote
- Updated at: 2026-03-27T15:58:22.265Z

## Artifact Summary
- resume: Spatial Business Systems resume package (user_reviewed, complete)
- job_description: Spatial Business Systems opportunity description (user_reviewed, complete)
