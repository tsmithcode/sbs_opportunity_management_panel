# Candidate story for Spatial Business Systems

## Story Summary
Software Engineer, Design Tools narrative built from lifecycle evidence, structured signals, and profile context.

## Who
I am Senior IC with architecture depth. My current narrative shows that I bring C#, .NET, Autodesk ecosystem, CAD tooling, performance-sensitive workflows.

## What
I am pursuing the Software Engineer, Design Tools opportunity at Spatial Business Systems with a focus on clear, supportable evidence rather than generic claims.

## Why
This opportunity matters because it connects through Recruiter outreach and aligns to the target role of Software Engineer, Design Tools.

## Where
I create value in Remote.

## When
The current timeline signals include upcoming milestones are still being clarified.

## How
I communicate and execute by leaning on Desktop software, Autodesk integrations, enterprise design systems.

## Proof Points
Experience or signal linked to Spatial Business Systems, Experience or signal linked to Autodesk-heavy engineering evidence ready, Experience or signal linked to Revit API emphasis and Autodesk platform

## Gaps To Address
Revit API depth needs explicit ramp narrative

## Interview And Outreach Cues
No interview-specific signals captured yet.

## Structured Signals
- Names: None captured
- Emails: None captured
- Phones: None captured
- Companies: Spatial Business Systems, Autodesk-heavy engineering evidence ready, Revit API emphasis and Autodesk platform
- Locations: None captured
- Contingencies: None captured


---
- Story ID: `story_mn935np2_gu7cyp`
- Status: review
- Updated at: 2026-03-27T15:58:22.262Z
