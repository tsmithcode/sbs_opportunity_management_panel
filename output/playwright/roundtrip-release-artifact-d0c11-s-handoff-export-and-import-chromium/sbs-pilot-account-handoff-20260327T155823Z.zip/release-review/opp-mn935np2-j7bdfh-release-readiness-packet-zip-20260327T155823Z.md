# Release readiness packet ZIP

- Review ID: `release_review_1774627102851`
- Account ID: `acct_mn935np2_9s81le`
- Opportunity ID: `opp_mn935np2_j7bdfh`
- Source name: sbs-pilot-account-release-readiness-packet-20260327T155822Z.zip
- Imported at: 2026-03-27T15:58:22.851Z

## Summary
Release summary and buyer-facing readiness materials imported for in-app review.

## Entries
- README.md
- release-summary.md
- release-summary.json
- buyer-readiness-packet.md
- summary key: generatedAt
- summary key: summary
- summary key: lastValidatedPhase
- summary key: localChecks
- summary key: ciChecks
- summary key: currentCoverage

## Content Preview
# Release Readiness Packet

This packet was generated locally from the current Monyawn workspace.

## Included Files
- release-summary.md
- release-summary.json
- buyer-readiness-packet.md

## Use Guidance
- This packet is human-readable and exportable.
- It does not replace the durable handoff ZIP used for full workspace recovery.
- It is intended for release review, buyer-readiness review, and internal operational handoff.


# Release Summary

## Summary
Release verification is scripted, automated, and visible. Local verification and CI both run the same build and browser gates, with desktop scenario proof plus a CEO-visible Habasit web/mobile town-hall proof on Chromium.

## Local Checks
- `npm run build`
- `npm run smoke`
- `npm run desktop:e2e`
- `npm run townhall:habasit`
- `npm run roundtrip`
- `npm run verify`
- `npm run smoke:cross-browser`

## CI Checks
- GitHub Actions verify workflow runs npm run verify on push, pull request, and manual dispatch.
- GitHub Actions cross-browser smoke matrix runs chromium, firefox, and webkit.

## Current Coverage
- Production build verification
- Chromium smoke verification for guided, admin, and About surfaces
- Chromium desktop end-to-end proof for three realistic opportunity scenarios
- Chromium Habasit America town-hall proof with one desktop web pass and one mobile pass against a 30-day seeded sample workspace
- Chromium round-trip verification for handoff ZIP and buyer packet ZIP
- Cross-browser smoke verification for chromium, firefox, and webkit

## Current Limits
- Desktop scenario proof and Habasit web/mobile town-hall proof are Chromium-only.
- The heavier generic mobile three-scenario proof exists as a separate extended script and is not part of the default release gate yet.
- Round-trip export/import verification remains Chromium-only.
- CI result status is surfaced through repo docs and workflow files, not a hosted dashboard.

## Expert Owners
- `Desktop Experience Director`
- `Mobile Experience Lead`
- `Town Hall Review Lead`
- `E2E Proof Lead`
- `Data Pipeline Validation Lead`
- `Visual QA Lead`
- `Responsive QA Lead`
- `CI / Release Automation Lead`
- `Browser Compatibility Lead`
- `QA / Reliability Lead`
- `Engineering Lead`
- `Release Manager`


# Buyer-Facing Readiness Packet

Generated: `2026-03-27T15:58:22.774Z`

## Current Workspace
- Account: SBS Pilot Account
- Account type: enterprise
- Opportunity: Spatial Business Systems - Software Engineer, Design Tools
- Stage: Intake complete
- Buyer readiness stage: buyer_reviewable
- Deployment posture: Local-only browser workspace with ZIP handoff packages.

## Product Posture
- Local-only data custody in the current version
- Human-in-the-loop operating model
- Export-first recovery posture with ZIP handoff packages
- Candidate story, coaching, and buyer packet workflows are available in-product

## Release Confidence
- Last validated phase: Habasit town hall proof and seeded product hardening
- Local checks: 7
- CI checks: 2
- Last export: No export yet recorded

## Current Limits
- Desktop scenario proof and Habasit web/mobile town-hall proof are Chromium-only.
- The heavier generic mobile three-scenario proof exists as a separate extended script and is not part of the default release gate yet.
- Round-trip export/import verification remains Chromium-only.
- CI result status is surfaced through repo docs and workflow files, not a hosted dashboard.

## Expert Owners
- `Desktop Experience Director`
- `Mobile Experience Lead`
- `Town Hall Review Lead`
- `E2E Proof Lead`
- `Data Pipeline Validation Lead`
- `Visual QA Lead`
- `Responsive QA Lead`
- `CI / Release Automation Lead`
- `Browser Compatibility Lead`
- `QA / Reliability Lead`
- `Engineering Lead`
- `Release Manager`

