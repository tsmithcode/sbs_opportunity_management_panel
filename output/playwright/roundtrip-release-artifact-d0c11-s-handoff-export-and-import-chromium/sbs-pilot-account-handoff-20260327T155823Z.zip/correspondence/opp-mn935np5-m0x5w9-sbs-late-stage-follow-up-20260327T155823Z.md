# SBS late-stage follow-up

- Correspondence ID: `cor_mn935np5_git8zj`
- Opportunity ID: `opp_mn935np5_m0x5w9`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T15:58:22.265Z

## Body
I appreciate the continued conversation. I would like to make sure scope, level, and compensation reflect both immediate contribution and long-term fit.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
