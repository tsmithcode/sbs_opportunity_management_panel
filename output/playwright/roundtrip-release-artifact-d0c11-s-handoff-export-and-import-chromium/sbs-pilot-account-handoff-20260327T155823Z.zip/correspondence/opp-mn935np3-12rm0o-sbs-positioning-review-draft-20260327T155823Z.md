# SBS positioning review draft

- Correspondence ID: `cor_mn935np5_etq0mx`
- Opportunity ID: `opp_mn935np3_12rm0o`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T15:58:22.265Z

## Body
I can contribute quickly in Autodesk-centric engineering workflows while staying hands-on and execution-focused.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
