# SBS intake follow-up draft

- Correspondence ID: `cor_mn8sp1sz_rjwae0`
- Opportunity ID: `opp_mn8sp1sy_d75dvk`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T11:05:31.235Z

## Body
Thank you for the outreach. I have strong Autodesk platform experience and would like to continue the conversation about the design tools role.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
