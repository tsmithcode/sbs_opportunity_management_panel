# SBS positioning review draft

- Correspondence ID: `cor_mn8sp1t1_bbi8rj`
- Opportunity ID: `opp_mn8sp1t0_kljpc8`
- Channel: email
- Status: draft
- Owner role: CRM / Correspondence Operations Lead
- Created at: 2026-03-27T11:05:31.237Z

## Body
I can contribute quickly in Autodesk-centric engineering workflows while staying hands-on and execution-focused.

## Extracted Signals
- Names: None
- Emails: None
- Dates: None
- Times: None
- Interviews: None
