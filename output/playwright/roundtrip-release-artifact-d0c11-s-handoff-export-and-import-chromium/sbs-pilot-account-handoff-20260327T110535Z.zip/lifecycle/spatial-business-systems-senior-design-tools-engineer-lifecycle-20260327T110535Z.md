# Spatial Business Systems - Senior Design Tools Engineer

- Opportunity ID: `opp_mn8sp1t1_p8opsb`
- Stage: Debrief captured
- Status: active
- Source: Panel continuation
- Employment type: Full-time
- Location type: Remote
- Updated at: 2026-03-27T11:05:31.238Z

## Artifact Summary
- resume: Spatial Business Systems resume package (user_reviewed, complete)
- job_description: Spatial Business Systems opportunity description (user_reviewed, complete)
