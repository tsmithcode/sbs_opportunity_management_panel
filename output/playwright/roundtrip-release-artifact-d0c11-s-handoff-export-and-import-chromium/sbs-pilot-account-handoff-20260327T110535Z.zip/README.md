# Monyawn Handoff Package

This export package was generated locally. Monyawn does not retain this session on company systems.

## Package Metadata
- Package version: 1.0.0
- Schema version: 0.2.0
- Generated at: 2026-03-27T11:05:35.224Z
- Account ID: acct_mn8sp1sy_o3keuf
- Selected user ID: user_seed_primary
- Selected opportunity ID: opp_mn8sp1sy_d75dvk

## Contents
- session.json
- manifest.json
- README.md
- lifecycle/
- candidate-story/
- memos/
- correspondence/
- support/
- reports/
- pdf/
- dictionaries/

## Restore Guidance
- Import this ZIP back into Monyawn to restore the session from `session.json`.
- Human-readable Markdown files and printable PDFs are included for review and handoff.
- If local browser storage is cleared, this package is the durable recovery mechanism.
