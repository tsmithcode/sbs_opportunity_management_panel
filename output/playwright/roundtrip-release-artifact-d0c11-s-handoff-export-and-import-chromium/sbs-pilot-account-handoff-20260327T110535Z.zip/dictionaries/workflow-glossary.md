# Workflow Glossary

- Intake started: Opportunity record exists, but evidence is still incomplete.
- Intake complete: Core artifacts and profile are present.
- Fit review: The platform is evaluating strengths, risks, and pursue logic.
- Positioning: Narrative, proof points, and role framing are under review.
- Outreach ready: Correspondence is being reviewed before external use.
- Interview active: Preparation or live interview support is in progress.
- Debrief captured: Interview outcomes have been recorded.
- Offer review: Compensation, level, and decision tradeoffs are being reviewed.
