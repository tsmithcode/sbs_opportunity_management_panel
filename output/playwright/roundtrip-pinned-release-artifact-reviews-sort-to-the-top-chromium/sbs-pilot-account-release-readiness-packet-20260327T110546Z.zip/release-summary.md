# Release Summary

## Summary
Release verification is scripted, automated, and visible. Local verification and CI both run the same build and browser gates.

## Local Checks
- `npm run build`
- `npm run smoke`
- `npm run roundtrip`
- `npm run verify`
- `npm run smoke:cross-browser`

## CI Checks
- GitHub Actions verify workflow runs npm run verify on push, pull request, and manual dispatch.
- GitHub Actions cross-browser smoke matrix runs chromium, firefox, and webkit.

## Current Coverage
- Production build verification
- Chromium smoke verification for guided, admin, and About surfaces
- Chromium round-trip verification for handoff ZIP and buyer packet ZIP
- Cross-browser smoke verification for chromium, firefox, and webkit

## Current Limits
- Round-trip export/import verification remains Chromium-only.
- CI result status is surfaced through repo docs and workflow files, not a hosted dashboard.

## Expert Owners
- `CI / Release Automation Lead`
- `Browser Compatibility Lead`
- `QA / Reliability Lead`
- `Engineering Lead`
- `Release Manager`
