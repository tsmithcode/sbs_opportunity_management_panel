# Spatial Business Systems - Software Engineer, Design Tools

- Opportunity ID: `opp_mn935lej_w4ozo8`
- Stage: Intake complete
- Status: active
- Source: Recruiter outreach
- Employment type: Full-time
- Location type: Remote
- Updated at: 2026-03-27T15:58:19.292Z

## Artifact Summary
- resume: Spatial Business Systems resume package (user_reviewed, complete)
- job_description: Spatial Business Systems opportunity description (user_reviewed, complete)
