# Spatial Business Systems - Software Engineer, Design Tools

- Opportunity ID: `opp_mn8sous8_agisru`
- Stage: Intake complete
- Status: active
- Source: Recruiter outreach
- Employment type: Full-time
- Location type: Remote
- Updated at: 2026-03-27T11:05:22.136Z

## Artifact Summary
- resume: Spatial Business Systems resume package (user_reviewed, complete)
- job_description: Spatial Business Systems opportunity description (user_reviewed, complete)
